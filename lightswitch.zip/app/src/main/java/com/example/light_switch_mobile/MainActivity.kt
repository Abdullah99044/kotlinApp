package com.example.light_switch_mobile

import android.content.Context
import android.hardware.camera2.CameraManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.annotation.RequiresApi

class MainActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main);

        val button = findViewById<Button>(R.id.Button1);
        button.setText("...");

        // schijf hier tussen je (setup) code



        // schijf hier tussen je (setup) code

    }

    // schijf hier tussen je eventuele function(s)


    // schijf hier tussen je eventuele function(s)
}
